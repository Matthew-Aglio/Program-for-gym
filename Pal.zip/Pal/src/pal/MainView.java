
package pal;

import javax.swing.*;
import java.awt.*;

public class MainView extends JFrame {
    private CardLayout layout;
    private JPanel cards;

    public MainView() {
        layout = new CardLayout();
        cards = new JPanel(layout);

        IscrittiPanel iscrittiPanel = new IscrittiPanel();
        IscrittiPresenter iscrittiPresenter = new IscrittiPresenter(iscrittiPanel);
        iscrittiPanel.setPresenter(iscrittiPresenter);
        cards.add(iscrittiPanel, "Iscritti");

        add(cards);
        layout.show(cards, "Iscritti");

        setTitle("Gestione Palestra");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(600, 400);
        setVisible(true);
    }
}
