
package pal;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class IscrittiPanel extends JPanel {
    private DefaultListModel<String> listaModel;
    private JList<String> lista;
    private JTextField nomeField, cognomeField, codiceFiscaleField, cercaField;
    private JComboBox<String> tipoAbbonamentoBox;
    private IscrittiPresenter presenter;

    public IscrittiPanel() {
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new BorderLayout());
        cercaField = new JTextField();
        topPanel.add(new JLabel("Cerca per Codice Fiscale: "), BorderLayout.WEST);
        topPanel.add(cercaField, BorderLayout.CENTER);
        add(topPanel, BorderLayout.NORTH);

        listaModel = new DefaultListModel<>();
        lista = new JList<>(listaModel);
        add(new JScrollPane(lista), BorderLayout.CENTER);

        JPanel formPanel = new JPanel(new GridLayout(6, 2));
        nomeField = new JTextField();
        cognomeField = new JTextField();
        codiceFiscaleField = new JTextField();
        tipoAbbonamentoBox = new JComboBox<>(new String[]{"Mensile", "Annuale"});
        JButton aggiungiBtn = new JButton("Aggiungi Iscritto");
        JButton rimuoviBtn = new JButton("Rimuovi Iscritto");

        formPanel.add(new JLabel("Nome:"));
        formPanel.add(nomeField);
        formPanel.add(new JLabel("Cognome:"));
        formPanel.add(cognomeField);
        formPanel.add(new JLabel("Codice Fiscale:"));
        formPanel.add(codiceFiscaleField);
        formPanel.add(new JLabel("Tipo Abbonamento:"));
        formPanel.add(tipoAbbonamentoBox);
        formPanel.add(aggiungiBtn);
        formPanel.add(rimuoviBtn);

        add(formPanel, BorderLayout.SOUTH);

        aggiungiBtn.addActionListener(e -> {
            presenter.aggiungiIscritto(
                nomeField.getText(),
                cognomeField.getText(),
                codiceFiscaleField.getText(),
                (String) tipoAbbonamentoBox.getSelectedItem()
            );
        });

        rimuoviBtn.addActionListener(e -> {
            String selected = lista.getSelectedValue();
            if (selected != null) {
                String codiceFiscale = selected.substring(selected.lastIndexOf("(") + 1, selected.lastIndexOf(")"));
                presenter.rimuoviIscritto(codiceFiscale);
            }
        });

        cercaField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                presenter.cercaIscritto(cercaField.getText());
            }
        });
    }

    public void setPresenter(IscrittiPresenter presenter) {
        this.presenter = presenter;
    }

    public void aggiornaLista(List<Iscritto> iscritti) {
        listaModel.clear();
        for (Iscritto i : iscritti) {
            StringBuilder sb = new StringBuilder();
            sb.append(i.getNome()).append(" ").append(i.getCognome())
              .append(" (").append(i.getCodiceFiscale()).append(")");
            List<Abbonamento> attivi = i.getAbbonamentiAttivi();
            if (!attivi.isEmpty()) {
                Abbonamento ab = attivi.get(attivi.size() - 1);
                sb.append(" - Abbonamento: ").append(ab.getTipo())
                  .append(" (dal ").append(ab.getInizio())
                  .append(" al ").append(ab.getFine()).append(")");
            }
            listaModel.addElement(sb.toString());
        }
    }
}