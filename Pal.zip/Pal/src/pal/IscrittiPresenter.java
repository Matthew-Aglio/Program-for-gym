
package pal;


import java.time.LocalDate;
import java.util.List;

public class IscrittiPresenter {
    private IscrittiPanel view;
    private ArchivioDati model;

    public IscrittiPresenter(IscrittiPanel view) {
        this.view = view;
        this.model = ArchivioDati.getInstance();
        view.aggiornaLista(model.getIscritti());
    }

    public void aggiungiIscritto(String nome, String cognome, String codiceFiscale, String tipoAbbonamento) {
        Iscritto iscritto = new Iscritto(nome, cognome, codiceFiscale);
        LocalDate oggi = LocalDate.now();
        LocalDate fine;
        if (tipoAbbonamento.equalsIgnoreCase("Annuale")) {
            fine = oggi.plusYears(1);
        } else {
            fine = oggi.plusMonths(1);
        }
        Abbonamento ab = new Abbonamento(oggi, fine, tipoAbbonamento);
        iscritto.aggiungiAbbonamento(ab);
        model.aggiungiIscritto(iscritto);
        view.aggiornaLista(model.getIscritti());
    }

    public void rimuoviIscritto(String codiceFiscale) {
        model.rimuoviIscritto(codiceFiscale);
        view.aggiornaLista(model.getIscritti());
    }

    public void cercaIscritto(String codiceFiscaleParziale) {
        List<Iscritto> trovati = model.cercaPerCodiceFiscale(codiceFiscaleParziale);
        view.aggiornaLista(trovati);
    }
}