
package pal;

import java.util.*;

public class Iscritto {
    private String nome;
    private String cognome;
    private String codiceFiscale;
    private List<Abbonamento> abbonamenti;

    public Iscritto(String nome, String cognome, String codiceFiscale) {
        this.nome = nome;
        this.cognome = cognome;
        this.codiceFiscale = codiceFiscale;
        this.abbonamenti = new ArrayList<>();
    }

    public void aggiungiAbbonamento(Abbonamento abbonamento) {
        abbonamenti.add(abbonamento);
    }

    public List<Abbonamento> getAbbonamentiAttivi() {
        return abbonamenti.stream().filter(Abbonamento::isAttivo).toList();
    }

    public List<Abbonamento> getStoricoAbbonamenti() {
        return abbonamenti;
    }

    public String getNome() { return nome; }
    public String getCognome() { return cognome; }
    public String getCodiceFiscale() { return codiceFiscale; }
    public List<Abbonamento> getAbbonamenti() { return abbonamenti; }
}