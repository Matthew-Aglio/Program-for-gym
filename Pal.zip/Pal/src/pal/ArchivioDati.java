
package pal;

import java.io.*;
import java.time.LocalDate;
import java.util.*;

public class ArchivioDati {
    private static ArchivioDati instance;
    private List<Iscritto> iscritti;
    private final String FILE_CSV = "iscritti.csv";

    private ArchivioDati() {
        iscritti = new ArrayList<>();
        caricaDaCSV();
    }

    public static ArchivioDati getInstance() {
        if (instance == null) instance = new ArchivioDati();
        return instance;
    }

    public void aggiungiIscritto(Iscritto i) {
        iscritti.add(i);
        salvaSuCSV();
    }

    public void rimuoviIscritto(String codiceFiscale) {
        iscritti.removeIf(i -> i.getCodiceFiscale().equalsIgnoreCase(codiceFiscale));
        salvaSuCSV();
    }

    public List<Iscritto> getIscritti() {
        return iscritti;
    }

    public List<Iscritto> cercaPerCodiceFiscale(String codice) {
        return iscritti.stream()
                .filter(i -> i.getCodiceFiscale().toLowerCase().contains(codice.toLowerCase()))
                .toList();
    }

    private void caricaDaCSV() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_CSV))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] dati = line.split(",");
                String nome = dati[0];
                String cognome = dati[1];
                String codiceFiscale = dati[2];
                Iscritto iscritto = new Iscritto(nome, cognome, codiceFiscale);
                for (int i = 3; i < dati.length; i += 4) {
                    LocalDate inizio = LocalDate.parse(dati[i]);
                    LocalDate fine = LocalDate.parse(dati[i + 1]);
                    double prezzo = Double.parseDouble(dati[i + 2]);
                    String tipo = dati[i + 3];
                    Abbonamento ab = new Abbonamento(inizio, fine, prezzo, tipo);
                    iscritto.aggiungiAbbonamento(ab);
                }
                iscritti.add(iscritto);
            }
        } catch (IOException e) {
            System.out.println("Errore nel caricamento dati: " + e.getMessage());
        }
    }

    public void salvaSuCSV() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE_CSV))) {
            for (Iscritto i : iscritti) {
                StringBuilder sb = new StringBuilder();
                sb.append(i.getNome()).append(",")
                  .append(i.getCognome()).append(",")
                  .append(i.getCodiceFiscale());
                for (Abbonamento ab : i.getAbbonamenti()) {
                    sb.append(",").append(ab.getInizio())
                      .append(",").append(ab.getFine())
                      .append(",").append(ab.getPrezzo())
                      .append(",").append(ab.getTipo());
                }
                pw.println(sb);
            }
        } catch (IOException e) {
            System.out.println("Errore nel salvataggio dati: " + e.getMessage());
        }
    }
}