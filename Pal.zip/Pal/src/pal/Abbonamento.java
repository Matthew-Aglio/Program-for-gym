
package pal;

import java.time.LocalDate;

public class Abbonamento {
    private LocalDate inizio;
    private LocalDate fine;
    private double prezzo;
    private String tipo; // ora è una stringa ("Mensile" o "Annuale")

    public Abbonamento(LocalDate inizio, LocalDate fine, double prezzo, String tipo) {
        this.inizio = inizio;
        this.fine = fine;
        this.prezzo = prezzo;
        this.tipo = tipo;
    }

    public boolean isAttivo() {
        return fine.isAfter(LocalDate.now());
    }

    public LocalDate getInizio() { return inizio; }
    public LocalDate getFine() { return fine; }
    public double getPrezzo() { return prezzo; }
    public String getTipo() { return tipo; }
}
