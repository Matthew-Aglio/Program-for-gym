
package pal;

import java.time.LocalDate;

public class Abbonamento {
    private LocalDate inizio;
    private LocalDate fine;
    private String tipo; // ora è una stringa ("Mensile" o "Annuale")

    public Abbonamento(LocalDate inizio, LocalDate fine, String tipo) {
        this.inizio = inizio;
        this.fine = fine;
        this.tipo = tipo;
    }

    public boolean isAttivo() {
        return fine.isAfter(LocalDate.now());
    }

    public LocalDate getInizio() { return inizio; }
    public LocalDate getFine() { return fine; }
    public String getTipo() { return tipo; }
}
